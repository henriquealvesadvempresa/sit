import React from 'react';
import { PhoneIcon } from './icons/PhoneIcon';
import { EmailIcon } from './icons/EmailIcon';
import { WhatsAppIcon } from './icons/WhatsAppIcon';
import { useTranslations } from '../i18n';

const Contact: React.FC = () => {
  const { t } = useTranslations();
  const phoneNumber = '+5511953920483';
  const email = 'paulo@direitoparavoce.com';
  const whatsappNumber = '5511953920483';
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(t('whatsapp_greeting'))}`;

  return (
    <section id="contato" className="py-20 bg-zinc-100 dark:bg-zinc-900 text-zinc-800 dark:text-white">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-zinc-900 dark:text-white mb-4">{t('contact_title')}</h2>
        <p className="text-lg text-gray-600 dark:text-gray-300 mb-12 max-w-2xl mx-auto">
          {t('contact_subtitle')}
        </p>
        <div className="flex flex-col md:flex-row justify-center items-center gap-6">
          <a 
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center w-full md:w-auto bg-amber-600 text-white font-bold py-4 px-8 rounded-lg text-lg hover:bg-amber-500 transition-colors duration-300"
          >
            <WhatsAppIcon />
            <span className="ml-3">{t('contact_whatsapp')}</span>
          </a>
          <a 
            href={`tel:${phoneNumber}`}
            className="flex items-center justify-center w-full md:w-auto bg-zinc-200 hover:bg-zinc-300 dark:bg-zinc-700 dark:hover:bg-zinc-600 text-zinc-800 dark:text-white font-bold py-4 px-8 rounded-lg text-lg transition-colors duration-300"
          >
            <PhoneIcon />
            <span className="ml-3">{t('contact_phone')}</span>
          </a>
          <a 
            href={`mailto:${email}`}
            className="flex items-center justify-center w-full md:w-auto bg-zinc-200 hover:bg-zinc-300 dark:bg-zinc-700 dark:hover:bg-zinc-600 text-zinc-800 dark:text-white font-bold py-4 px-8 rounded-lg text-lg transition-colors duration-300"
          >
            <EmailIcon />
            <span className="ml-3">{t('contact_email')}</span>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Contact;