import React from 'react';
import { useTranslations } from '../i18n';

const Footer: React.FC = () => {
  const { t } = useTranslations();
  const currentYear = new Date().getFullYear();
  return (
    <footer className="bg-zinc-100 text-gray-500 dark:bg-zinc-900 dark:text-gray-400 py-6">
      <div className="container mx-auto px-6 text-center">
        <p>{t('footer_copyright', { year: currentYear })}</p>
        <p className="text-sm mt-2">{t('footer_author')}</p>
      </div>
    </footer>
  );
};

export default Footer;