import React, { useState, useEffect } from 'react';
import { useTranslations } from '../i18n';
import LanguageSwitcher from './LanguageSwitcher';
import ThemeSwitcher from './ThemeSwitcher';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const { t } = useTranslations();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md dark:bg-zinc-900' : 'bg-white/30 backdrop-blur-sm dark:bg-black/30'}`}>
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <a href="#" className={`text-2xl font-bold transition-colors text-zinc-900 dark:text-white`}>
          {t('header_title')}
        </a>
        
        <div className="hidden md:flex items-center gap-4">
            <nav className="flex space-x-8">
              <a href="#areas" className={`text-sm font-medium transition-colors text-gray-600 hover:text-zinc-900 ${isScrolled ? 'dark:text-gray-300' : 'dark:text-gray-200'} dark:hover:text-white`}>{t('nav_areas')}</a>
              <a href="#contato" className={`text-sm font-medium transition-colors text-gray-600 hover:text-zinc-900 ${isScrolled ? 'dark:text-gray-300' : 'dark:text-gray-200'} dark:hover:text-white`}>{t('nav_contact')}</a>
            </nav>
            <LanguageSwitcher isScrolled={isScrolled} />
            <ThemeSwitcher isScrolled={isScrolled} />
            <a href="#contato" className={`px-4 py-2 rounded-md text-sm font-semibold transition-all duration-300 ${isScrolled ? 'border border-amber-600 text-amber-600 hover:bg-amber-600 hover:text-white' : 'bg-amber-600 text-white hover:bg-amber-500'}`}>
              {t('nav_cta')}
            </a>
        </div>
      </div>
    </header>
  );
};

export default Header;