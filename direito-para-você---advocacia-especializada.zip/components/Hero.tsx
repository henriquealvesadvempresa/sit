import React from 'react';
import { useTranslations } from '../i18n';

const Hero: React.FC = () => {
  const { t } = useTranslations();

  return (
    <section 
      id="home" 
      className="relative h-screen flex items-center justify-center text-center bg-cover bg-center bg-no-repeat bg-fixed"
      style={{ backgroundImage: "url('https://storage.googleapis.com/caiquestorageforcreatesite/Untitled.png')" }}
    >
      <div className="absolute inset-0 bg-black opacity-50"></div>
      <div className="z-10 text-white px-6">
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-4">
          {t('hero_title')}
        </h1>
        <p className="text-lg md:text-xl lg:text-2xl mb-8 max-w-3xl mx-auto font-light text-gray-300">
          {t('hero_subtitle')}
        </p>
        <a 
          href="#contato" 
          className="bg-amber-600 text-white font-bold py-3 px-8 rounded-lg text-lg hover:bg-amber-500 transition-colors duration-300"
        >
          {t('hero_cta')}
        </a>
      </div>
    </section>
  );
};

export default Hero;