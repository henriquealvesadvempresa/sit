import React from 'react';
import { useTranslations } from '../i18n';

const Industries: React.FC = () => {
  const { t } = useTranslations();
  const industries = t('industries_list') as unknown as string[];

  return (
    <section id="industries" className="py-20 bg-white dark:bg-zinc-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">{t('industries_title')}</h2>
        </div>
        <div className="columns-2 md:columns-3 lg:columns-4 gap-x-8">
          {industries.map((industry) => (
            <div key={industry} className="mb-4 break-inside-avoid">
              <p className="text-gray-700 dark:text-gray-300">{industry}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Industries;