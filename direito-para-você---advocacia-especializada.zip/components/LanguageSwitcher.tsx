import React from 'react';
import { useTranslations, Locale } from '../i18n';

interface LanguageSwitcherProps {
  isScrolled: boolean;
}

const LanguageSwitcher: React.FC<LanguageSwitcherProps> = ({ isScrolled }) => {
  const { locale, setLocale } = useTranslations();

  const switchLanguage = (lang: Locale) => {
    setLocale(lang);
  };

  const getButtonStyle = (lang: Locale) => {
    const baseStyle = 'cursor-pointer font-semibold text-sm px-2 py-1 rounded-md transition-colors';
    const activeStyle = 'bg-amber-600 text-white';
    
    const inactiveStyle = isScrolled
      ? 'text-gray-500 hover:text-zinc-900 dark:text-gray-400 dark:hover:text-white'
      : 'text-gray-700 hover:text-zinc-900 dark:text-gray-200 dark:hover:text-white';
      
    return `${baseStyle} ${locale === lang ? activeStyle : inactiveStyle}`;
  };

  return (
    <div className={`flex items-center space-x-1 p-1 rounded-lg ${isScrolled ? 'bg-gray-100 dark:bg-zinc-800' : 'bg-white/20 dark:bg-black/20'}`}>
      <button 
        onClick={() => switchLanguage('pt-BR')} 
        className={getButtonStyle('pt-BR')}
        aria-pressed={locale === 'pt-BR'}
        aria-label="Mudar para Português"
      >
        PT
      </button>
      <span className={isScrolled ? 'text-gray-300 dark:text-zinc-600' : 'text-gray-500 dark:text-gray-300'}>|</span>
      <button 
        onClick={() => switchLanguage('en-US')} 
        className={getButtonStyle('en-US')}
        aria-pressed={locale === 'en-US'}
        aria-label="Switch to English"
      >
        EN
      </button>
    </div>
  );
};

export default LanguageSwitcher;