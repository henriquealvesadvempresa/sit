import React from 'react';
import { ScaleIcon } from './icons/ScaleIcon';
import { BuildingIcon } from './icons/BuildingIcon';
import { ShieldCheckIcon } from './icons/ShieldCheckIcon';
import { useTranslations } from '../i18n';

const PracticeAreaCard: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode }> = ({ icon, title, children }) => {
  return (
    <div className="bg-white dark:bg-zinc-900 p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-1">
      <div className="flex items-center justify-center h-16 w-16 rounded-full bg-zinc-900 dark:bg-amber-600 text-white dark:text-zinc-900 mb-6">
        {icon}
      </div>
      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">{title}</h3>
      <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{children}</p>
    </div>
  );
};

const PracticeAreas: React.FC = () => {
  const { t } = useTranslations();
  return (
    <section id="areas" className="py-20 bg-zinc-50 dark:bg-zinc-800">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">{t('areas_title')}</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 mt-4 max-w-2xl mx-auto">
            {t('areas_subtitle')}
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          <PracticeAreaCard icon={<ScaleIcon />} title={t('area_civil_title')}>
            {t('area_civil_desc')}
          </PracticeAreaCard>
          <PracticeAreaCard icon={<BuildingIcon />} title={t('area_admin_title')}>
            {t('area_admin_desc')}
          </PracticeAreaCard>
          <PracticeAreaCard icon={<ShieldCheckIcon />} title={t('area_business_title')}>
            {t('area_business_desc')}
          </PracticeAreaCard>
        </div>
      </div>
    </section>
  );
};

export default PracticeAreas;