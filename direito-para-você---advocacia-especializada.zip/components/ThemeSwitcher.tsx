import React from 'react';
import { useTheme } from '../theme';
import { SunIcon } from './icons/SunIcon';
import { MoonIcon } from './icons/MoonIcon';
import { ComputerDesktopIcon } from './icons/ComputerDesktopIcon';

interface ThemeSwitcherProps {
  isScrolled: boolean;
}

const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({ isScrolled }) => {
  const { theme, setTheme } = useTheme();

  const getButtonStyle = (buttonTheme: string) => {
    const baseStyle = 'p-1 rounded-md transition-colors duration-300 flex items-center justify-center';
    const activeStyle = 'bg-amber-600 text-white';
    
    const inactiveStyle = isScrolled
        ? 'text-gray-500 hover:text-zinc-900 dark:text-gray-400 dark:hover:text-white'
        : 'text-gray-700 hover:text-zinc-900 dark:text-gray-200 dark:hover:text-white';

    return `${baseStyle} ${theme === buttonTheme ? activeStyle : inactiveStyle}`;
  };

  return (
    <div className={`flex items-center space-x-1 p-1 rounded-lg ${isScrolled ? 'bg-gray-100 dark:bg-zinc-800' : 'bg-white/20 dark:bg-black/20'}`}>
      <button onClick={() => setTheme('light')} className={getButtonStyle('light')} aria-pressed={theme === 'light'} aria-label="Switch to light theme">
        <SunIcon className="w-5 h-5" />
      </button>
      <button onClick={() => setTheme('dark')} className={getButtonStyle('dark')} aria-pressed={theme === 'dark'} aria-label="Switch to dark theme">
        <MoonIcon className="w-5 h-5" />
      </button>
      <button onClick={() => setTheme('system')} className={getButtonStyle('system')} aria-pressed={theme === 'system'} aria-label="Switch to system theme">
        <ComputerDesktopIcon className="w-5 h-5" />
      </button>
    </div>
  );
};

export default ThemeSwitcher;
