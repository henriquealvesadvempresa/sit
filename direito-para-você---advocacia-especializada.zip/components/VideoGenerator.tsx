import React from 'react';
import { GoogleGenAI } from '@google/genai';
import { useTranslations } from '../i18n';

// Helper to convert file to base64
const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

const VideoGenerator: React.FC = () => {
    const { t } = useTranslations();
    const [isKeySelected, setIsKeySelected] = React.useState(false);
    const [image, setImage] = React.useState<{ data: string; mimeType: string; preview: string } | null>(null);
    const [prompt, setPrompt] = React.useState('Animate this statue. The scales of justice gently sway and the sword gleams.');
    const [aspectRatio, setAspectRatio] = React.useState<'16:9' | '9:16'>('16:9');
    const [isLoading, setIsLoading] = React.useState(false);
    const [loadingMessage, setLoadingMessage] = React.useState('');
    const [videoUrl, setVideoUrl] = React.useState<string | null>(null);
    const [error, setError] = React.useState<string | null>(null);

    React.useEffect(() => {
        const checkKey = async () => {
            if (window.aistudio) {
                const hasKey = await window.aistudio.hasSelectedApiKey();
                setIsKeySelected(hasKey);
            }
        };
        checkKey();
    }, []);

    const loadingMessages = React.useMemo(() => [
        t('video_generating_status'),
        t('video_polling_status'),
        t('video_finalizing_status'),
    ], [t]);

    React.useEffect(() => {
        // FIX: Use `ReturnType<typeof setInterval>` for browser compatibility instead of NodeJS specific types.
        let interval: ReturnType<typeof setInterval>;
        if (isLoading) {
            let i = 0;
            setLoadingMessage(loadingMessages[i]);
            interval = setInterval(() => {
                i = (i + 1) % loadingMessages.length;
                setLoadingMessage(loadingMessages[i]);
            }, 5000);
        }
        return () => clearInterval(interval);
    }, [isLoading, loadingMessages]);


    const handleSelectKey = async () => {
        await window.aistudio.openSelectKey();
        // Assume success to avoid race condition
        setIsKeySelected(true);
    };

    const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const base64String = await toBase64(file);
            const [header, data] = base64String.split(',');
            const mimeType = header.match(/:(.*?);/)?.[1] || 'image/png';
            setImage({ data, mimeType, preview: URL.createObjectURL(file) });
            setVideoUrl(null); // Clear previous video
            setError(null);
        }
    };

    const handleGenerateVideo = async () => {
        if (!image) return;

        setError(null);
        setIsLoading(true);
        setVideoUrl(null);

        try {
            // Re-check key right before the call
            const hasKey = await window.aistudio.hasSelectedApiKey();
            if (!hasKey) {
                setIsKeySelected(false);
                throw new Error("API Key not selected.");
            }

            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            let operation = await ai.models.generateVideos({
                model: 'veo-3.1-fast-generate-preview',
                prompt: prompt,
                image: {
                    imageBytes: image.data,
                    mimeType: image.mimeType,
                },
                config: {
                    numberOfVideos: 1,
                    resolution: '720p',
                    aspectRatio: aspectRatio
                }
            });

            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 10000));
                operation = await ai.operations.getVideosOperation({ operation: operation });
            }
            
            const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;

            if (downloadLink) {
                 const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                 const blob = await response.blob();
                 setVideoUrl(URL.createObjectURL(blob));
            } else {
                throw new Error("Video generation failed to return a valid link.");
            }

        } catch (err: any) {
            console.error(err);
             if (err.message?.includes("Requested entity was not found")) {
                setError(t('video_error'));
                setIsKeySelected(false); // Reset key state
            } else {
                 setError(t('video_error'));
            }
        } finally {
            setIsLoading(false);
        }
    };
    
    if (!isKeySelected) {
        return (
            <section id="video-generator-key" className="py-20 bg-white dark:bg-zinc-900">
                <div className="container mx-auto px-6 text-center">
                     <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">{t('video_title')}</h2>
                     <p className="text-lg text-gray-600 dark:text-gray-300 mt-4 max-w-2xl mx-auto">{t('video_select_key_prompt')}</p>
                     <div className="mt-8 flex flex-col items-center gap-4">
                        <button
                            onClick={handleSelectKey}
                            className="bg-amber-600 text-white font-bold py-3 px-8 rounded-lg text-lg hover:bg-amber-500 transition-colors duration-300"
                        >
                            {t('video_select_key_button')}
                        </button>
                        <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-sm text-gray-600 hover:text-amber-600 dark:text-gray-400 dark:hover:text-amber-500 underline">
                            {t('video_billing_link')}
                        </a>
                     </div>
                </div>
            </section>
        );
    }


    return (
        <section id="video-generator" className="py-20 bg-white dark:bg-zinc-900">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16">
                    <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">{t('video_title')}</h2>
                    <p className="text-lg text-gray-600 dark:text-gray-300 mt-4 max-w-3xl mx-auto">
                        {t('video_subtitle')}
                    </p>
                </div>

                <div className="max-w-4xl mx-auto bg-zinc-50 dark:bg-zinc-800 p-8 rounded-lg shadow-lg">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">{t('video_upload_label')}</label>
                            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md">
                                <div className="space-y-1 text-center">
                                    {image?.preview ? (
                                        <img src={image.preview} alt="Preview" className="mx-auto h-48 w-auto rounded-md object-contain"/>
                                    ) : (
                                        <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    )}
                                    <div className="flex text-sm text-gray-600 dark:text-gray-400 justify-center">
                                        <label htmlFor="file-upload" className="relative cursor-pointer bg-white dark:bg-zinc-800 rounded-md font-medium text-amber-600 hover:text-amber-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-amber-500">
                                            <span>Upload a file</span>
                                            <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/*" onChange={handleImageChange} />
                                        </label>
                                    </div>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">PNG, JPG up to 10MB</p>
                                </div>
                            </div>
                        </div>

                        <div className="flex flex-col space-y-6">
                            <div>
                                <label htmlFor="prompt" className="block text-sm font-medium text-gray-700 dark:text-gray-200">Prompt</label>
                                <textarea
                                    id="prompt"
                                    rows={4}
                                    className="mt-1 block w-full rounded-md border-gray-300 dark:border-zinc-600 shadow-sm focus:border-amber-500 focus:ring-amber-500 sm:text-sm p-2 bg-white dark:bg-zinc-700 dark:text-white dark:placeholder-gray-400"
                                    value={prompt}
                                    onChange={(e) => setPrompt(e.target.value)}
                                    placeholder={t('video_prompt_placeholder')}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">{t('video_aspect_ratio_label')}</label>
                                <fieldset className="mt-2">
                                    <legend className="sr-only">Aspect ratio</legend>
                                    <div className="flex items-center space-x-4">
                                        <div className="flex items-center">
                                            <input id="landscape" name="aspect-ratio" type="radio" value="16:9" checked={aspectRatio === '16:9'} onChange={() => setAspectRatio('16:9')} className="h-4 w-4 border-gray-300 text-amber-600 focus:ring-amber-500" />
                                            <label htmlFor="landscape" className="ml-3 block text-sm font-medium text-gray-700 dark:text-gray-300">{t('video_aspect_ratio_landscape')}</label>
                                        </div>
                                        <div className="flex items-center">
                                            <input id="portrait" name="aspect-ratio" type="radio" value="9:16" checked={aspectRatio === '9:16'} onChange={() => setAspectRatio('9:16')} className="h-4 w-4 border-gray-300 text-amber-600 focus:ring-amber-500" />
                                            <label htmlFor="portrait" className="ml-3 block text-sm font-medium text-gray-700 dark:text-gray-300">{t('video_aspect_ratio_portrait')}</label>
                                        </div>
                                    </div>
                                </fieldset>
                            </div>
                            <button
                                onClick={handleGenerateVideo}
                                disabled={!image || isLoading}
                                className="w-full bg-amber-600 text-white font-bold py-3 px-8 rounded-lg text-lg hover:bg-amber-500 transition-colors duration-300 disabled:bg-gray-400 disabled:cursor-not-allowed"
                            >
                                {isLoading ? loadingMessage : t('video_generate_button')}
                            </button>
                        </div>
                    </div>

                    {error && (
                        <div className="mt-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
                            <p>{error}</p>
                        </div>
                    )}

                    {(isLoading || videoUrl) && (
                        <div className="mt-8">
                            <div className="w-full bg-zinc-900 rounded-lg overflow-hidden" style={{paddingTop: aspectRatio === '16:9' ? '56.25%' : '177.78%', position: 'relative'}}>
                                <div className="absolute top-0 left-0 w-full h-full">
                                    {isLoading && !videoUrl && (
                                        <div className="flex items-center justify-center h-full">
                                            <div className="text-center text-white">
                                                <svg className="animate-spin -ml-1 mr-3 h-10 w-10 text-white mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                                </svg>
                                                <p className="mt-4 text-lg">{loadingMessage}</p>
                                            </div>
                                        </div>
                                    )}
                                    {videoUrl && (
                                        <video src={videoUrl} controls autoPlay loop className="w-full h-full object-contain"></video>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </section>
    );
};

export default VideoGenerator;